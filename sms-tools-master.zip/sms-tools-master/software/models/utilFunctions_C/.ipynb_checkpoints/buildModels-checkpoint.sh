python compileModule.py build_ext --inplace
